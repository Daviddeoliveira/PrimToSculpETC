<?php
use App\Http\Controllers\MongoTest;

if (isset($_GET['submit'])){
	MongoTest::mongoInsert($_GET['email'], $_GET['nbUser'] , $_GET['zipCode'], $_GET['uuid']);
	MongoTest::mongoCountUsers($_GET['nbUser']);
}

$nbUser = MongoTest::mongoCountUsers();
$realNbUser = 0;

foreach ($nbUser as $user) {
	foreach($user as $souwou){
		$realNbUser += $souwou;
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Le masque de bonob0h</title>
	<meta charset="utf-8">
	<link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" >
	<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" >
	<link rel="icon" type="image/png" href="image/meza.png">
</head>

<body class="fondue">

	<center>
		<h1>#LeMasqueDeBonob<U>0</U>h</h1><br>

		<div class="bg-secondary">
			<p style="color: lightgrey">Je te protège,tu me protège,il se protège,nous nous protègons,vous vous protègez,ils se protègent,<br>
			des postillons pour ralentir la propagasion du #Covid19,et moins encomber Hopitaux,Soignantiels </p>
		</div>

		<iframe src="https://www.youtube.com/embed/biM_In672PY" width="100%" frameborder="100" width="1920" height="400" allowfullscreen></iframe>

		<div class="bg-light-custom" style="margin-bottom: 8px">
			<div class="col-md-4 border border-secondary rounded">
				<p  class=""><b><font size="10pt"><?php echo e($realNbUser); ?></font></b><br>
					<b>personnes utilisant déjà</b><br>
					#LeMasqueDeBonob0h
				</p>
			</div>
		</div>

			<div class="bg-light">
				<h4 style="color: grey">Vous pouvez modifier les informations suivantes :</h4>
			</div><br>
			<div class="container">
				<div  class="row justify-content-center align-items-center ">
					<div class="col-md-6">
						<div class="col-md-12">
							<form method="get">
								<div class="form-group">
									<h4>Confirmation de votre UUID:</h4>
									<input type="text" name="uuid" class="form-control">
									<h4>Nombre d'utilisateurs</h4>
									<input name="nbUser" class="form-control" type="number" min="1" value="1" required>
								</div>
								<div class="form-group">
									<h4>Code Postal</h4>
									<input name="zipCode" type="text" class="form-control" placeholder="Exemple : 77170">
								</div>
								<div class="form-group">
									<h4>Adresse Email</h4>
									<input type="email" name="email" class="form-control" placeholder="Exemple : toto@gmail.com">
								</div>
								<button name="submit" type="submit" class="btn btn-secondary">Envoyer</button>
							</form><br>
						</div>
					</div>
				</div>
			</div>
		</div>

		<a href="/"><button name="submit" type="submit" class="btn btn-success">Retour</button></a>
		<div class="bg-danger">
			<h2><a href="donation.html" style="color: lightgrey">Aidez la sante </a></h2>
		</div>
		<a href="#" style="color: black">Merci de pensez à SIGNER la Pétition</a><br><br>
		<a href="/map"><button name="submit" type="submit" class="btn btn-success">Voir les utilisateurs par commune</button></a>
	</center>

</body>
<?php /**PATH D:\telechargement\laragon\laragon\www\site-masque2\resources\views/mongoInsertModif.blade.php ENDPATH**/ ?>