<!DOCTYPE html>
<html>
<head>
	<title>form test</title>
</head>
<body>
	<form method="get">
		<input type="text" name="sksk">
		<input type="submit" name="jhehehe" value="aaaaaaa">
	</form>
</body>
</html><?php /**PATH C:\laragon\www\site-masque2\resources\views/formTest.blade.php ENDPATH**/ ?>