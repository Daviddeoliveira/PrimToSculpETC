<!DOCTYPE html>
<html>
<head>
	<title>mongo test</title>
</head>
<body>
	<h1>mongo test en fait</h1>
	<?php echo e($yeet); ?>

</body>
</html><?php /**PATH C:\laragon\www\site-masque\resources\views/mongoTest.blade.php ENDPATH**/ ?>