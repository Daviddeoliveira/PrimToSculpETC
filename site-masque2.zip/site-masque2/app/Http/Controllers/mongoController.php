<?php

namespace App\Http\Controllers;

use MongoDB\Client as Mongo;
use Illuminate\Http\Request;

class MongoTest extends Controller
{

	public static function  mongoInsert($mail , $nbUsers, $zipCode , $uuid){
		$mongo = new Mongo;
			//$index = $mongo->site_bonoboh->users->createIndex(array('uuid'=>$uuid),array('unique'=>true));
		$insertOneResult = $mongo->site_bonoboh->users->updateOne(array('_id'=>$uuid),
			array('$set'=>array(
				'nbUesrs' => $nbUsers,
				'mail' => $mail,
				'zipCode' => $zipCode,
				'admin' => false,
			)),
			array('upsert' => true)
		);
		return view('mongoInsert1', compact('insertOneResult'));
	}

	public static function mongoCountUsers(){
		$mongo = new Mongo;
		$nbUser = $mongo->site_bonoboh->users->find([],['projection'=>['nbUesrs'=>1 , '_id'=>0]])->toArray();
		return $nbUser;
	}

	public static function mongoUserZip(){
		$mongo = new Mongo;
		$zipUseur = $mongo->site_bonoboh->users->find([],['projection'=>['zipCode'=>1 , '_id'=>0]])->toArray();
		return $zipUseur;
	}

	public static function mongoCountUsersZip($zipCode){
		$mongo = new Mongo;
		$cuz = $mongo->site_bonoboh->users->find(['zipCode'=>$zipCode],['projection'=>['nbUesrs'=>1 , '_id'=>0]])->toArray();
		return $cuz;
	}

	public static function mongoInfoUser($uuid){
		$mongo = new Mongo;
		$info = $mongo->site_bonoboh->users->find(['_id'=>$uuid],['projection'=>['nbUesrs'=>1 , '_id'=>0]])->toArray();
		return $info;
	}

	public static function mongoInfoMail($uuid){
		$mongo = new Mongo;
		$info = $mongo->site_bonoboh->users->find(['_id'=>$uuid],['projection'=>['mail'=>1 , '_id'=>0]])->toArray();
		return $info;
	}

	public static function mongoInfoZip($uuid){
		$mongo = new Mongo;
		$info = $mongo->site_bonoboh->users->find(['_id'=>$uuid],['projection'=>['zipCode'=>1 , '_id'=>0]])->toArray();
		return $info;
	}
}
