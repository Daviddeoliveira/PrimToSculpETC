<?php
use App\Http\Controllers\MongoTest;

if(isset($_GET['uuid'])){
	$user = MongoTest::mongoInfoUser($_GET['uuid']);

		$nUser = 0;
		foreach ($user as $key) {
			foreach ($key as $value) {
				$nUser = $value;
			}
		}
		$zip = MongoTest::mongoInfoZip($_GET['uuid']);

		$uZip = 0;
		foreach ($zip as $key) {
			foreach ($key as $value) {
				$uZip = $value;
			}
		}

		$mail = MongoTest::mongoInfoMail($_GET['uuid']);

		$uMail = 0;
		foreach ($mail as $key) {
			foreach ($key as $value) {
				$uMail = $value;
			}
		}
}


$nbUser = MongoTest::mongoCountUsers();
$realNbUser = 0;

foreach ($nbUser as $user) {
	foreach($user as $souwou){
		$realNbUser += $souwou;
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Le masque de bonob0h</title>
	<meta charset="utf-8">
	<link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet" type="text/css" >
	<link href="{{ asset('css/style.css') }}" rel="stylesheet" type="text/css" >
	<link rel="icon" type="image/png" href="image/meza.png">
</head>
<body class="fondue">
  <center>
    <h1>#LeMasqueDeBonob<U>0</U>h</h1><br>

		<div class="bg-secondary">
			<p style="color: lightgrey">Je te protège,tu me protège,il se protège,nous nous protègons,vous vous protègez,ils se protègent,<br>
			des postillons pour ralentir la propagasion du #Covid19,et moins encomber Hopitaux,Soignantiels </p>
		</div>

		<iframe src="https://www.youtube.com/embed/biM_In672PY" width="100%" frameborder="100" width="1920" height="400" allowfullscreen></iframe>

		<div class="bg-light-custom" style="margin-bottom: 8px">
			<div class="col-md-4 border border-secondary rounded">
				<p  class=""><b><font size="10pt">{{$realNbUser}}</font></b><br>
					<b>personnes utilisant déjà</b><br>
					#LeMasqueDeBonob0h
				</p>
			</div>
		</div>

    <div class="container">
      <h5>Entrez votre UUID:</h5>
			<div class="col-md-6">
				<form method="get">
          <input type="text" name="uuid" id="myInput" class="form-control" style="margin-right: 3px">
          <input style="margin-right: 2px; margin-bottom : 10px" type="submit" name="validate" value="valider" class="btn btn-secondary"><br>
        </form>
			</div>

      @if(isset($_GET['uuid']))
      <div class="bg-light">
				<h4 style="color: grey">Vous informations complémentaire sont les suivantes :</h4>
			</div><br>
      <div class="container">
        <h4>Nombre d'utilisateurs : @if(isset($_GET['uuid'])) {{$nUser}} @endif</h4><br>
        <h4>Votre mail :</h4><br>
        <p><strong>@if(isset($_GET['uuid'])) {{$uZip}} @endif</strong></p><br>
        <h4>Votre Code Postal :</h4>
        <p>@if(isset($_GET['uuid'])) {{$uMail}} @endif</p>
      </div>
			<a href="/Modifier"><button name="submit" type="submit" class="btn btn-secondary">Modifier</button></a>
      @endif
    </div>

		<br><a href="/"><button name="submit" type="submit" class="btn btn-success">Retour</button></a>
    <div class="bg-danger">
      <h2><a href="donation.html" style="color: lightgrey">Aidez la sante </a></h2>
    </div>
    <a href="#" style="color: black">Merci de pensez à SIGNER la Pétition</a><br><br>
    <a href="/map"><button name="submit" type="submit" class="btn btn-success">Voir les utilisateurs par commune</button></a>

  </center>
</body>
