<?php
use App\Http\Controllers\MongoTest;

$nbUser = MongoTest::mongoCountUsers();
$realNbUser = 0;
$zipUseur = 0;

if (isset($_GET['zipCode'])){
	$nb = MongoTest::mongoCountUsersZip($_GET['zipCode']);
	foreach ($nb as $key) {
			foreach ($key as $value ) {
					$zipUseur += $value;
				}
			}

}
foreach($nbUser as $user) {
	foreach($user as $souwou){
		$realNbUser += $souwou;
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Le masque de bonob0h</title>
	<link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet" type="text/css" >
	<link href="{{ asset('css/style.css') }}" rel="stylesheet" type="text/css" >
	<link rel="icon" type="image/png" href="image/meza.png">
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css"
	 integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ==" crossorigin=""/>
</head>
<body>

	<center>
		<h1>#LeMasqueDeBonob<U>0</U>h</h1><br>

		<div class="bg-secondary">
			<p style="color: lightgrey">Je te protège,tu me protège,il se protège,nous nous protègons,vous vous protègez,ils se protègent,<br>
			des postillons pour ralentir la propagasion du #Covid19,et moins encomber Hopitaux,Soignantiels </p>
		</div>

		<div class="bg-light-custom" style="margin-bottom: 8px">
			<div class="col-md-4 border border-secondary rounded">
				<p  class=""><b><font size="10pt">{{$realNbUser}}</font></b><br>
					<b>personnes utilisant déjà</b><br>
					#LeMasqueDeBonob0h
				</p>
			</div>
		</div>

			<h4>Nombre d'utilisateur(s) par commune</h4><br>

			<h6 style="color: lightgrey">Entrez votre code Postal</h6><br>

			<div class="container">
				<div class="col-md-6">
					<form method="get">
						<input type="text" name="zipCode" id="myInput" class="form-control" style="margin-right: 3px"><br>
						<input style="margin-right: 2px; margin-bottom : 10px" type="submit" name="validate"  id="zip" value="valider" class="btn btn-primary">
					</form>
				</div>
			</div>

			<div class="bg-secondary">
				<h4 style="color: lightgrey">Il y a {{$zipUseur}} utilisateur(s) dans la commune:	@if(isset($_GET['zipCode']))	{{$_GET['zipCode']}} 	@endif</h4>
			</div><br><br>

			<div id="maCarte"></div>

				<!-- Fichiers Javascript -->
        <script src="https://unpkg.com/leaflet@1.5.1/dist/leaflet.js"
				 integrity="sha512-GffPMF3RvMeYyc1LWMHtK8EbPv0iNZ8/oTtHPx9/cc2ILxQ+u905qIwdpULaqDkyBKgOaB57QTMg7ztg8Jm2Og==" crossorigin=""></script>
        <script>

						// On initialise la carte
            var carte = L.map('maCarte').setView([48.852969, 2.349903], 9);

            // On charge les "tuiles"
            L.tileLayer('https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png', {
                attribution: 'données © <a href="//osm.org/copyright">OpenStreetMap</a>/ODbL - rendu <a href="//openstreetmap.fr">OSM France</a>',
                minZoom: 5,
                maxZoom: 15,
            }).addTo(carte);

						let zipCode = document.getElementById('myInput')

						zipCode.addEventListener("change", function(){
							ajaxGet(`https://nominatim.openstreetmap.org/search?q=${this.value}&format=json&addressdetails=1&limit=1&polygon_svg=1`).then(reponse => {
        			let data = JSON.parse(reponse)
        			code = [data[0].lat, data[0].lon]
        			carte.panTo(code)

							var marker = L.marker([data[0].lat, data[0].lon]).addTo(carte);
							marker.bindPopup("<?php echo json_encode($zipUseur); ?>")
    })
})

						function ajaxGet(url){
    					return new Promise(function(resolve, reject){
        			let xmlhttp = new XMLHttpRequest();

        			xmlhttp.onreadystatechange = function(){
            		if(xmlhttp.readyState == 4){
                	if(xmlhttp.status == 200){
                    	resolve(xmlhttp.responseText);
                			}else{
                    		reject(xmlhttp);
                	}
            }
        }
        xmlhttp.onerror = function(error){
            reject(error);
        }
        xmlhttp.open('GET', url, true);

        xmlhttp.send(null);
    })
}
        </script>

			<br><br>
			<a href="/"><button name="submit" type="submit" class="btn btn-success">Retour</button></a>
			<div class="bg-danger">
				<h2><a href="donation.html" style="color: lightgrey">Aidez la sante </a></h2>
			</div>
			<a href="#" style="color: black">Merci de pensez à SIGNER la Pétition</a>

	</center>

</body>
</html>
