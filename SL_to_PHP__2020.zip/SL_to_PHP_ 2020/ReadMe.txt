SLtoPHP
est la partie externe d'un script sur SecondLife qui a partir de modélisation de "Prims" dans SL, permet d'exporter dans un format de fichier dit Scultp.
Ce format Sclupt est interne a SL et permet de faire des objets complexe contant pour un seul Prim

Le but de ce projet est :
Faire fonctionner la partie PHP qui à des problèmes
Ensuite le but sera de transformer pour que ça génère d'autres formats de fichiers comme le Collada .dae un format 3D libre qui permet d'importer ensuite dans d'autres logiciel de 3D, et dans le Format .STL qui permet d'Imprimer en 3D.

A voir si on garde le fonctionnement en PHP ou si on transpose en JS

La partie PHP est déjà installée sur 

Compte FTP
Hote : ftpperso.free.fr
login  : c3dsl
passwd : zep1k1

Il y a déjà des modification de l'original qui à des erreurs de PHP
Il faut donc déjà regarder ou peuvent se trouver les erreurs de PHP, etc
et faire fonctionner.

La partie Script sur SL qui intéragit vous sera communiquée sur SL ;) 

